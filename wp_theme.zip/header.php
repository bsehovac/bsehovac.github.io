<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <meta name="description" content="<?php echo get_bloginfo('description'); ?>">
	<meta name="author" content="<?php echo get_bloginfo('name'); ?>">
  <?php wp_head();?>
</head>
<body <?php body_class(); ?>>
  <div id="navigation">
    <div class="center clear">
      <a href="<?php echo home_url(); ?>" id="navigation-logo" class="logo"><span><?php echo get_bloginfo('name'); ?></span></a>
      <div id="menu-trigger"><i class="fa fa-bars" aria-hidden="true"></i></div>
      <?php
        wp_nav_menu(array(
          'theme_location' => 'primary_menu',
          'menu_id' => 'menu',
          'menu_class' => 'clear',
          'container' => ''
        ));
      ?>
    </div>
  </div>
