/*
██   ██ ███████ ██      ██████  ███████ ██████  ███████
██   ██ ██      ██      ██   ██ ██      ██   ██ ██
███████ █████   ██      ██████  █████   ██████  ███████
██   ██ ██      ██      ██      ██      ██   ██      ██
██   ██ ███████ ███████ ██      ███████ ██   ██ ███████
*/

var ready, each, addClass, removeClass, hasClass, remove, getOffset, mergeArray, getParent, ajax, css, animate;

(function() {

  // document ready
  ready = function(fn) {
    if (document.attachEvent ? document.readyState === "complete" : document.readyState !== "loading")
      fn();
    else
      document.addEventListener('DOMContentLoaded', fn);
  };

  // for each element in array
  each = function(el, fn) {
    for (var i = 0; i < el.length; i++) {
      fn(el[i], i);
    }
  };

  // add class to element
  addClass = function(el, className) {
    if (typeof el !== 'object' || el == null) return false;
    if (el.classList)
      el.classList.add(className);
    else
      el.className += ' ' + className;
    return el;
  };

  // remove class from element
  removeClass = function(el, className) {
    if (typeof el !== 'object' || el == null) return false;
    if (el.classList)
      el.classList.remove(className);
    else
      el.className = el.className.replace(new RegExp('(^|\\b)' + className.split(' ').join('|') + '(\\b|$)', 'gi'), ' ');
    return el;
  };

  // check if element has class
  hasClass = function(el, className) {
    if (typeof el !== 'object' || el == null) return false;
    if (el.classList)
      return el.classList.contains(className);
    else
      return new RegExp('(^| )' + className + '( |$)', 'gi').test(el.className);
  };

  // remove element
  remove = function(el) {
    if (typeof el !== 'object') return false;
    el.parentNode.removeChild(el);
    return true;
  };

  // get element position, relative to document or viewport
  getOffset = function(el, viewport) {
    if (typeof el !== 'object') return false;
    if (typeof viewport === 'undefined') viewport = false;
    var rect = el.getBoundingClientRect();
    return { top: rect.top + ((!viewport) ? document.body.scrollTop : 0), left: rect.left + ((!viewport) ? document.body.scrollLeft : 0), width: rect.width, height: rect.height };
  };

  // merge 2 arrrays into one
  mergeArray = function(array1, array2) {
    for (var key in array1) {
      if (array1.setStyles.hasOwnProperty(key)) array2[key] = array1[key];
    }
    return array2;
  };

  // find parent by query
  getParent = function(el, query) {
    switch(query.charAt(0)) {
      case '#': {
        query = query.replace('#', '');
        while ((el = el.parentElement) && el.getAttribute('id') != query);
        return el;
      }
      case '.': {
        query = query.replace('.', '');
        while ((el = el.parentElement) && !hasClass(el, query));
        return el;
      }
      default: {
        query = query.toLowerCase();
        while ((el = el.parentElement) && el.tagName.toLowerCase() != query);
        return el;
      }
    }
    return false;
  };

  // simple ajax function
  ajax = function(options) {
    if (typeof options === 'undefined') return false;
    var defaults = { url: window.location.href, method: 'post', data: {}, success: false }, data = '';
    options = mergeArray(options, defaults);
    for (var key in options.data) {
      if (options.data.hasOwnProperty(key)) {
        data += key +'='+ encodeURIComponent(options.data[key]) +'&';
      }
    }
    var xhr = new XMLHttpRequest();
    xhr.open(options.method, options.url);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
      if (xhr.status === 200) {
        if ( options.success ) options.success(xhr.responseText);
      } else {
        options.success(false);
      }
    };
    xhr.send(data);
  };

  /*
   █████  ███    ██ ██ ███    ███  █████  ████████ ███████
  ██   ██ ████   ██ ██ ████  ████ ██   ██    ██    ██
  ███████ ██ ██  ██ ██ ██ ████ ██ ███████    ██    █████
  ██   ██ ██  ██ ██ ██ ██  ██  ██ ██   ██    ██    ██
  ██   ██ ██   ████ ██ ██      ██ ██   ██    ██    ███████
  */

  // get style prefix
  var getPrefix = function(property) {
    var vendors  = ['Webkit', 'Moz', 'O', 'ms'];
    var vendorProperty = property.charAt(0).toUpperCase() + property.substr(1);
    var div = document.createElement('div');
    if (div.style[property] !== undefined) return property;
    for (var i = 0; i < vendors.length; i++) {
      if (div.style[vendors[i]+vendorProperty] !== undefined) return vendors[i]+vendorProperty;
    }
    return false;
  };

  // transform and transition prefix
  var prefix = {
    transform: getPrefix('transform'),
    transition: getPrefix('transition')
  };

  // ie9 request animation frame
  (function(animationFrame) {
    var lastTime = 0;
    var vendors = ['webkit', 'moz'];
    for(var x = 0; x < vendors.length && !window.requestAnimationFrame; ++x) {
      window.requestAnimationFrame = window[vendors[x]+'RequestAnimationFrame'];
      window.cancelAnimationFrame = window[vendors[x]+'CancelAnimationFrame'] || window[vendors[x]+'CancelRequestAnimationFrame'];
    }
    if (!window.requestAnimationFrame) {
      window.requestAnimationFrame = function(callback, element) {
        var currTime = new Date().getTime();
        var timeToCall = Math.max(0, 16 - (currTime - lastTime));
        var id = window.setTimeout(function() { callback(currTime + timeToCall); }, timeToCall);
        lastTime = currTime + timeToCall;
        return id;
      };
    }
    if (!window.cancelAnimationFrame) window.cancelAnimationFrame = function(id) { clearTimeout(id); };
  }());

  // set element styles
  css = function(el, styles, cancel) {
    cancel = (typeof cancel === 'undefined') ? true : cancel;
    var setStyles = {};
    if (cancel) styles.transition = '';
    for (var key in styles) {
      if (styles.hasOwnProperty(key)) {
        if (el.style[key] !== undefined) {
          el.style[key] = setStyles[key] = styles[key];
        } else {
          if (el.style[prefix[key]] !== undefined ) el.style[prefix[key]] = setStyles[key] = styles[key];
        }
      }
    }
    el.setStyles = setStyles;
  };

  // animate element styles
  animate = function(el, styles) {
    if (typeof el === 'undefined' || typeof styles === 'undefined') return false;
    if (styles == 'stop') { animateStop(el); return false; }
    var duration = 500, easing = 'ease', callback = function() {}, reset = (styles.hasOwnProperty(0));
    for (var i = 2; i < arguments.length; i++) {
      if (typeof arguments[i] === 'function') callback = arguments[i];
      if (typeof arguments[i] === 'string') easing = arguments[i];
      if (typeof arguments[i] === 'number') duration = arguments[i];
    }
    if (typeof el.timeout !== 'undefined') clearTimeout(el.timeout);
    if (typeof el.setStyles !== 'undefined' && el.setStyles && !reset) animateStop(el);

    if (reset) {
      styles[0].transition = '';
      css(el, styles[0], false);
      window.requestAnimationFrame(function() {
        styles[1].transition = 'all '+ duration +'ms '+ easing;
        css(el, styles[1], false);
      });
    } else {
      styles.transition = 'all '+ duration +'ms '+ easing;
      css(el, styles, false);
    }
    el.timeout = setTimeout(function() {
      css(el, { transition: '' });
      el.setStyles = false;
      callback();
    }, duration);
  };

  function animateStop(el) {
    var setStyles = {};
    for (var key in el.setStyles) {
      if (el.setStyles.hasOwnProperty(key)) {
        setStyles[key] = getComputedStyle(el)[key]; // IE9+
      }
    }
    setStyles.transition = '';
    css(el, setStyles);
    el.animating = false;
    return false;
  }

})();

/*
 █████       ██  █████  ██   ██     ███████ ██    ██ ██████  ███    ███ ██ ████████
██   ██      ██ ██   ██  ██ ██      ██      ██    ██ ██   ██ ████  ████ ██    ██
███████      ██ ███████   ███       ███████ ██    ██ ██████  ██ ████ ██ ██    ██
██   ██ ██   ██ ██   ██  ██ ██           ██ ██    ██ ██   ██ ██  ██  ██ ██    ██
██   ██  █████  ██   ██ ██   ██     ███████  ██████  ██████  ██      ██ ██    ██
*/

function ajaxSubmit(options) {
  var form = document.querySelector(options.form);
  if (!document.body.contains(form)) return;
  var input = form.querySelectorAll(options.input);
  var submit = form.querySelector(options.submit);

  for ( var i = 0; i < input.length; i++ ){
    input[i].onfocus = function() {
      var errorParent = getParent(this, '.contact-holder');
      removeClass(errorParent, 'error');
      removeClass(this, 'error');
    };
  }

  submit.onclick = validateForm;
  form.onsubmit = validateForm;

  function validateForm(e) {
    e.preventDefault();
    if (!hasClass(submit, 'busy') && !hasClass(submit, 'disabled')) {
      var url = form.getAttribute('action');
      var method = form.getAttribute('method');
      var data = '';
      var error = false;
      var formtype;

      for (var i = 0; i < input.length; i++) {
        var el = input[i];
        var name = el.getAttribute('name');
        var value = el.value;
        var field_error = false;
        var post_field = true;
        if (name == 'type') formtype = value;
        if (el.hasAttribute('verify')){
          var verify = el.getAttribute('verify').split(' ');
          for (var j = 0; j < verify.length; j++) {
            if (
              (verify[j] == 'blank' && value != '') ||
              (verify[j] == 'required' && value == '') ||
              (verify[j] == 'email' && !isEmail(value)) ||
              (verify[j] == 'phone' && !isPhone(value))
            ) field_error = true;
          }
        }
        if (field_error) {
          error = true;
          if (formtype == 'subscribe') {
            addClass(el, 'error');
          } else {
            var errorParent = getParent(el, '.contact-holder');
            addClass(errorParent, 'error');
          }
        } else {
          if (formtype == 'subscribe') {
            removeClass(el, 'error');
          } else {
            var errorParent = getParent(el, '.contact-holder');
            removeClass(errorParent, 'error');
          }
        }
        if (post_field) data += name +'='+ value +'&';
      }

      if (!error) {
        addClass(submit, 'busy');
        var xhr = new XMLHttpRequest();
        xhr.open(method, url);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
          if (xhr.status === 200) {
            removeClass(submit, 'busy');
            addClass(submit, 'disabled');
            options.success(xhr.responseText);
          }
        };
        xhr.send(encodeURI(data));
        console.log(data);
      }

    }
    return false;
  }

  function isEmail (email) {
    var regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return regex.test(email);
  }

  function isPhone (phone) {
    phone = phone.replace(/\+|\-|\ |\/|\(|\)/g,'');
    return !isNaN(parseFloat(phone)) && isFinite(phone);
  }
}

/*
███    ███  ██████  ██████   █████  ██
████  ████ ██    ██ ██   ██ ██   ██ ██
██ ████ ██ ██    ██ ██   ██ ███████ ██
██  ██  ██ ██    ██ ██   ██ ██   ██ ██
██      ██  ██████  ██████  ██   ██ ███████
*/

var modal;

ready(function() {
  function Modal() {
    var m = this;
    m.container = document.querySelector('#modal');
    if (!document.body.contains(m.container)) return false;
    m.overlay   = document.querySelector('#modal-overlay');
    m.fixer     = document.querySelector('#modal-fixer');
    m.window    = document.querySelector('#modal-window');
    m.content   = document.querySelector('#modal-content');
    m.button    = document.querySelector('#modal-ok');
    m.button.onclick = function(e) {
      e.preventDefault();
      m.hide();
    };
    css(m.container, { position: 'fixed', display: 'none', top: 0, left: 0, width: '100%', height: '100%', textAlign: 'center', whiteSpace: 'nowrap', zIndex: 9999, fontSize: 0 });
    css(m.overlay, { position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', zIndex: 1 });
    css(m.fixer, { display: 'inline-block', height: '100%', verticalAlign: 'middle' });
    css(m.window, { position: 'relative', display: 'inline-block', zIndex: 2, overflow: 'hidden', verticalAlign: 'middle', whiteSpace: 'normal', fontSize: '16px' });
    return this;
  }

  Modal.prototype.text = function(html) {
    var m = this;
    m.content.innerHTML = html;
    return false;
  };

  Modal.prototype.show = function() {
    var m = this;
    css(m.container, { display: 'block' });
    css(m.overlay, { opacity: 0 });
    css(m.window, { opacity: 0, transform: 'translateY(20px)' });
    animate(m.overlay, { opacity: 1 }, 500);
    animate(m.window, { opacity: 1, transform: 'translateY(0px)' }, 500);
    return false;
  };

  Modal.prototype.hide = function() {
    var m = this;
    animate(m.overlay, { opacity: 0 }, 300);
    animate(m.window, { opacity: 0 }, 300, function() {
      css(m.container, { display: 'none' });
    });
    return false;
  };

  modal = new Modal();
});

/*
███████ ███    ███  ██████   ██████  ████████ ██   ██     ███████  ██████ ██████   ██████  ██      ██
██      ████  ████ ██    ██ ██    ██    ██    ██   ██     ██      ██      ██   ██ ██    ██ ██      ██
███████ ██ ████ ██ ██    ██ ██    ██    ██    ███████     ███████ ██      ██████  ██    ██ ██      ██
     ██ ██  ██  ██ ██    ██ ██    ██    ██    ██   ██          ██ ██      ██   ██ ██    ██ ██      ██
███████ ██      ██  ██████   ██████     ██    ██   ██     ███████  ██████ ██   ██  ██████  ███████ ███████
*/

function init(){if(!document.body)return;var e=document.body;var t=document.documentElement;var n=window.innerHeight;var r=e.scrollHeight;root=document.compatMode.indexOf("CSS")>=0?t:e;activeElement=e;initdone=true;if(top!=self){frame=true}else if(r>n&&(e.offsetHeight<=n||t.offsetHeight<=n)){var i=false;var s=function(){if(!i&&t.scrollHeight!=document.height){i=true;setTimeout(function(){t.style.height=document.height+"px";i=false},500)}};t.style.height="";setTimeout(s,10);addEvent("DOMNodeInserted",s);addEvent("DOMNodeRemoved",s);if(root.offsetHeight<=n){var o=document.createElement("div");o.style.clear="both";e.appendChild(o)}}if(document.URL.indexOf("mail.google.com")>-1){var u=document.createElement("style");u.innerHTML=".iu { visibility: hidden }";(document.getElementsByTagName("head")[0]||t).appendChild(u)}if(!fixedback&&!disabled){e.style.backgroundAttachment="scroll";t.style.backgroundAttachment="scroll"}}function scrollArray(e,t,n,r){r||(r=1e3);directionCheck(t,n);if(acceleration){var i=+(new Date);var s=i-lastScroll;if(s<accelDelta){var o=(1+30/s)/2;if(o>1){o=Math.min(o,accelMax);t*=o;n*=o}}lastScroll=+(new Date)}que.push({x:t,y:n,lastX:t<0?.99:-.99,lastY:n<0?.99:-.99,start:+(new Date)});if(pending){return}var u=e===document.body;var a=function(){var i=+(new Date);var s=0;var o=0;for(var f=0;f<que.length;f++){var l=que[f];var c=i-l.start;var h=c>=animtime;var p=h?1:c/animtime;if(pulseAlgorithm){p=pulse(p)}var d=l.x*p-l.lastX>>0;var v=l.y*p-l.lastY>>0;s+=d;o+=v;l.lastX+=d;l.lastY+=v;if(h){que.splice(f,1);f--}}if(u){window.scrollBy(s,o)}else{if(s)e.scrollLeft+=s;if(o)e.scrollTop+=o}if(!t&&!n){que=[]}if(que.length){requestFrame(a,e,r/framerate+1)}else{pending=false}};requestFrame(a,e,0);pending=true}function wheel(e){if(!initdone){init()}var t=e.target;var n=overflowingAncestor(t);if(!n||e.defaultPrevented||isNodeName(activeElement,"embed")||isNodeName(t,"embed")&&/\.pdf/i.test(t.src)){return true}var r=e.wheelDeltaX||0;var i=e.wheelDeltaY||0;if(!r&&!i){i=e.wheelDelta||0}if(Math.abs(r)>1.2){r*=stepsize/120}if(Math.abs(i)>1.2){i*=stepsize/120}scrollArray(n,-r,-i);e.preventDefault()}function keydown(e){var t=e.target;var n=e.ctrlKey||e.altKey||e.metaKey||e.shiftKey&&e.keyCode!==key.spacebar;if(/input|textarea|select|embed/i.test(t.nodeName)||t.isContentEditable||e.defaultPrevented||n){return true}if(isNodeName(t,"button")&&e.keyCode===key.spacebar){return true}var r,i=0,s=0;var o=overflowingAncestor(activeElement);var u=o.clientHeight;if(o==document.body){u=window.innerHeight}switch(e.keyCode){case key.up:s=-arrowscroll;break;case key.down:s=arrowscroll;break;case key.spacebar:r=e.shiftKey?1:-1;s=-r*u*.9;break;case key.pageup:s=-u*.9;break;case key.pagedown:s=u*.9;break;case key.home:s=-o.scrollTop;break;case key.end:var a=o.scrollHeight-o.scrollTop-u;s=a>0?a+10:0;break;case key.left:i=-arrowscroll;break;case key.right:i=arrowscroll;break;default:return true}scrollArray(o,i,s);e.preventDefault()}function mousedown(e){activeElement=e.target}function setCache(e,t){for(var n=e.length;n--;)cache[uniqueID(e[n])]=t;return t}function overflowingAncestor(e){var t=[];var n=root.scrollHeight;do{var r=cache[uniqueID(e)];if(r){return setCache(t,r)}t.push(e);if(n===e.scrollHeight){if(!frame||root.clientHeight+10<n){return setCache(t,document.body)}}else if(e.clientHeight+10<e.scrollHeight){overflow=getComputedStyle(e,"").getPropertyValue("overflow-y");if(overflow==="scroll"||overflow==="auto"){return setCache(t,e)}}}while(e=e.parentNode)}function addEvent(e,t,n){window.addEventListener(e,t,n||false)}function removeEvent(e,t,n){window.removeEventListener(e,t,n||false)}function isNodeName(e,t){return(e.nodeName||"").toLowerCase()===t.toLowerCase()}function directionCheck(e,t){e=e>0?1:-1;t=t>0?1:-1;if(direction.x!==e||direction.y!==t){direction.x=e;direction.y=t;que=[];lastScroll=0}}function pulse_(e){var t,n,r;e=e*pulseScale;if(e<1){t=e-(1-Math.exp(-e))}else{n=Math.exp(-1);e-=1;r=1-Math.exp(-e);t=n+r*(1-n)}return t*pulseNormalize}function pulse(e){if(e>=1)return 1;if(e<=0)return 0;if(pulseNormalize==1){pulseNormalize/=pulse_(1)}return pulse_(e)}var framerate=150;var animtime=400;var stepsize=80;var pulseAlgorithm=true;var pulseScale=8;var pulseNormalize=1;var acceleration=true;var accelDelta=10;var accelMax=1;var keyboardsupport=true;var disableKeyboard=false;var arrowscroll=50;var exclude="";var disabled=false;var frame=false;var direction={x:0,y:0};var initdone=false;var fixedback=true;var root=document.documentElement;var activeElement;var key={left:37,up:38,right:39,down:40,spacebar:32,pageup:33,pagedown:34,end:35,home:36};var que=[];var pending=false;var lastScroll=+(new Date);var cache={};setInterval(function(){cache={}},10*1e3);var uniqueID=function(){var e=0;return function(t){return t.uniqueID||(t.uniqueID=e++)}}();var requestFrame=function(){return window.requestAnimationFrame||window.webkitRequestAnimationFrame||function(e,t,n){window.setTimeout(e,n||1e3/60)}}();var uA=window.navigator.userAgent,safari=/Safari/i.test(uA),chrome=/Chrome/i.test(uA);if(safari&&chrome||!safari&&chrome||!safari&&!chrome){addEvent("mousedown",mousedown);addEvent("mousewheel",wheel);addEvent("load",init)}
