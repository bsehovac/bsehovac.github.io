<?php

include 'includes/clean_junk.php';
include 'includes/modal_window.php';

/**
*  ██████ ███████ ███████        ██             ██ ███████
* ██      ██      ██             ██             ██ ██
* ██      ███████ ███████     ████████          ██ ███████
* ██           ██      ██     ██  ██       ██   ██      ██
*  ██████ ███████ ███████     ██████        █████  ███████
*/

function add_css_and_js() {
  $theme_version = time();
  wp_enqueue_style('font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css', false, '1', 'all');
  wp_enqueue_style('google-fonts', '//fonts.googleapis.com/css?family=Roboto+Slab:400,700&amp;subset=latin-ext', false, '1', 'all');
  wp_enqueue_style('css-styles', get_template_directory_uri() . '/style.css', false, $theme_version, 'all');
  wp_enqueue_script('js-plugins', get_template_directory_uri() . '/js/plugins.js', false, $theme_version, true);
  wp_enqueue_script('js-scripts', get_template_directory_uri() . '/js/scripts.js', false, $theme_version, true);
}
add_action('wp_enqueue_scripts', 'add_css_and_js');

/**
* ███    ███ ███████ ███    ██ ██    ██
* ████  ████ ██      ████   ██ ██    ██
* ██ ████ ██ █████   ██ ██  ██ ██    ██
* ██  ██  ██ ██      ██  ██ ██ ██    ██
* ██      ██ ███████ ██   ████  ██████
*/

function register_my_menus() {
  register_nav_menus(array(
    'primary_menu' => 'Primary Menu',
    'social_menu' => 'Social Menu',
  ));
  add_theme_support('title-tag');
  function doc_title_separator() { return '&middot;'; }
  add_filter('document_title_separator', 'doc_title_separator');
}
add_action('after_setup_theme', 'register_my_menus');


/**
*  ██████ ██    ██ ███████ ████████  ██████  ███    ███     ██████   ██████  ███████ ████████
* ██      ██    ██ ██         ██    ██    ██ ████  ████     ██   ██ ██    ██ ██         ██
* ██      ██    ██ ███████    ██    ██    ██ ██ ████ ██     ██████  ██    ██ ███████    ██
* ██      ██    ██      ██    ██    ██    ██ ██  ██  ██     ██      ██    ██      ██    ██
*  ██████  ██████  ███████    ██     ██████  ██      ██     ██       ██████  ███████    ██
*/

/*function create_post_slideshow() {
	register_post_type('slideshow', array(
    'label'               => 'Slideshow',
    'public'              => true,
    'hierarchical'        => false,
    'has_archive'         => false,
    'query_var'           => true,
    'capability_type'     => 'post',
    'menu_position'       => 21,
    'exclude_from_search' => true,
    'show_in_nav_menus'   => false,
    'menu_icon'           => 'dashicons-images-alt2',
    'rewrite'             => array('slug' => 'slideshow'),
    'supports'            => array('title', 'page-attributes'),
  ));
}
add_action('init', 'create_post_slideshow');*/

/*$meta_boxes[] = array(
  'title'      => 'Slideshow Options', // meta box title
  'name'       => 'slideshow_options', // meta box name
  'post_type'  => 'slideshow', // post type or page
  'page_tpl'   => '', // if post_type is page enter page template path [template-parts/contact.php]
  // 'layout'    => 'columns' // (default value columns)
  // 'context'    => 'normal' // (default normal)
  // 'priority'   => 'default' // (default default)
  // 'meta_key'   => 'vm_custom_fields', // meta key to save in database and retrieve in theme (default value vm_custom_fields)
  'fields'     => array(
    array('type' => 'text', 'name' => 'title', 'title' => 'Title'), // name must be unique for every metabox on page with same meta_key
    array('type' => 'textarea', 'name' => 'text', 'title' => 'Text'),
    array('type' => 'editor',  'name' => 'editor', 'title' => 'Editor'),
    array('type' => 'image', 'name' => 'image', 'title' => 'Image'),
    array('type' => 'gallery',  'name' => 'gallery1', 'title' => 'Gallery 1'),
    array('type' => 'gallery',  'name' => 'gallery2', 'title' => 'Gallery 2', 'fields' => array('title', 'description', 'url')),
  ),
);*/

/**
* ███    ███ ███████ ████████  █████      ██████   ██████  ██   ██ ███████ ███████
* ████  ████ ██         ██    ██   ██     ██   ██ ██    ██  ██ ██  ██      ██
* ██ ████ ██ █████      ██    ███████     ██████  ██    ██   ███   █████   ███████
* ██  ██  ██ ██         ██    ██   ██     ██   ██ ██    ██  ██ ██  ██           ██
* ██      ██ ███████    ██    ██   ██     ██████   ██████  ██   ██ ███████ ███████
*/

$hide_editors[] = 'template-parts/home.php';

/*$meta_boxes[] = array(
  'title'      => 'Slideshow',
  'name'       => 'slideshow',
  'post_type'  => 'page',
  'page_tpl'   => 'template-parts/home.php',
  #'layout'     => 'single',
  'fields'     => array(
    array('type' => 'gallery', 'name' => 'slideshow', 'title' => 'Slides', 'fields' => array('title', 'description', 'url')),
    array('type' => 'text', 'name' => 'slideshow_interval', 'title' => 'Interval (seconds)'),
    array('type' => 'select', 'name' => 'slideshow_type', 'title' => 'Type', 'values' => array('dots' => 'Dots', 'arrows' => 'Arrows')),
  ),
);*/

$meta_boxes[] = array(
  'title'      => 'Test',
  'name'       => 'test',
  'post_type'  => 'page',
  'page_tpl'   => 'template-parts/home.php',
  'meta_key'   => 'wpcf',
  'context'    => 'normal',
  'priority'   => 'default',
  'fields'     => array(
    array(
      'type' => 'text',
      'name' => 'test_text',
      'title' => 'Test Text',
    ),
    array(
      'type' => 'textarea',
      'name' => 'test_textarea',
      'title' => 'Test Textarea',
    ),
    array(
      'type' => 'editor',
      'name' => 'test_editor',
      'title' => 'Test Editor',
    ),
    array(
      'type' => 'color',
      'name' => 'test_color',
      'title' => 'Test Color',
      'default' => '#0073aa',
    ),
    array(
      'type' => 'select',
      'name' => 'test_select',
      'title' => 'Test Select',
      'values' => array(
        'option_1' => 'Option 1',
        'option_2' => 'Option 2',
      ),
    ),
    array(
      'type' => 'image',
      'name' => 'test_image',
      'title' => 'Test Image',
    ),
    array(
      'type' => 'gallery',
      'name' => 'test_gallery',
      'title' => 'Test Gallery',
    ),
    array(
      'type' => 'gallery',
      'name' => 'test_gallery_extra',
      'title' => 'Test Gallery Extra',
      'fields' => array(
        'title', 
        'description',
        'url'
      ),
    ),
    array(
      'type' => 'files',
      'name' => 'test_files',
      'title' => 'Test Files',
    ),
  ),
);

/*$meta_boxes[] = array(
  'title'      => 'Test 2',
  'name'       => 'test_2',
  'post_type'  => 'page',
  'page_tpl'   => 'template-parts/home.php',
  'meta_key'   => 'wpcf',
  'context'    => 'normal',
  'priority'   => 'default',
  'fields'     => array(
    array('type' => 'text',     'name' => 'test_text_2',     'title' => 'Test Text 2'),
    array('type' => 'textarea', 'name' => 'test_textarea_2', 'title' => 'Test Textarea 2'),
    array('type' => 'editor',   'name' => 'test_editor_2',   'title' => 'Test Editor 2'),
    array('type' => 'select',   'name' => 'test_select_2',   'title' => 'Test Select 2'),
    array('type' => 'image',    'name' => 'test_image_2',    'title' => 'Test Image 2'),
    array('type' => 'gallery',  'name' => 'test_gallery_2',  'title' => 'Test Gallery 2'),
    array('type' => 'files',    'name' => 'test_files_2',    'title' => 'Test Files 2'),
  ),
);*/

include 'wpcf/init.php';