<?php

function color($meta, $meta_key, $field) {
  $name    = $meta_key . '[' . $field['name'] . ']';
  $value   = $meta[$field['name']];
  $default = $field['default'];
  $title   = $field['title'];
  $value   = (isset($value)) ? $value : ((isset($default)) ? $default : '#ffffff'); ?>

  <div class="field color">
    <label for="<?= $name ?>"><?= $title ?></label>
    <input type="text"
           name="<?= $name ?>"
           value="<?= $value ?>"
           style="background-color: <?= $value ?>;">
    <div class="colorpicker"></div>
  </div>

  <script>
    jQuery(document).ready(function($) {
      var input = $('.field.color input[name="<?= $name ?>"]');
      var parent = input.parents('.field');
      var picker = parent.find('.colorpicker');
      ColorPicker(picker[0], function(hex, hsv, rgb) {
        input[0].style.backgroundColor = hex;
      });
    });
  </script>

  <?php
}