<?php

function gallery_item($name, $extra, $extra_fields, $key = 'IMGID', $item = false, $gallery = false) {
  $blank = ($item) ? false : true;
  if ($blank) {
    $img   = '';
    $thumb = '';
    $input_name = 'nameplaceholder';
    $item_class = 'upload';
  } else {
    $img   = $item['img'];
    $thumb = wp_get_attachment_image_src($img, 'thumbnail')[0];
    $input_name = 'name';
    $item_class = 'item';
  } ?>

  <div class="<?=$item_class?>">
    <input class="meta" type="hidden" value="<?=$img?>"
      <?=$input_name?>="<?=$name?>[<?=$key?>][img]">
    <div class="image-preview" imgid="<?=$img?>" style="background-image: url(<?=$thumb?>)">
      <i class="dashicons dashicons-plus"></i>
      <i class="dashicons dashicons-trash"></i>
    </div>

    <?php if ($extra) { ?>
      <div class="extra">
      <?php foreach ($extra_fields as $extra_field) {
        $extra_field_value = ($blank) ? '' : $gallery[$key][$extra_field]; ?>
        <div class="extra-item">
          <label><?=$extra_field?></label>
          <input type="text" class="meta"
            value="<?=$extra_field_value?>"
            <?=$input_name?>="<?=$name?>[<?=$key?>][<?=$extra_field?>]">
        </div>
      <?php } ?>
      </div>
    <?php } ?>
  </div>
  <?php
}

function gallery($meta, $meta_key, $field) {
  $gallery = $meta[$field['name']];
  $name    = $meta_key . '[' . $field['name'] . ']';
  $title   = $field['title'];

  $extra        = isset($field['fields']);
  $extra_fields = ($extra) ? $field['fields'] : false;
  $extra_class  = ($extra) ? 'extras' : '';
  ?>

  <div class="field gallery <?=$extra_class?>">
    <label><?=$title?></label>

    <div class="items"><?php
      if (!empty($gallery)) {
        foreach ($gallery as $key => $item) {
          gallery_item($name, $extra, $extra_fields, $key, $item, $gallery);
        }
      }
      gallery_item($name, $extra, $extra_fields);
    ?></div>

  </div>

  <?php
}