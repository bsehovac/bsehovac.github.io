<?php

function text($meta, $meta_key, $field) {
  $name  = $meta_key . '[' . $field['name'] . ']';
  $value = $meta[$field['name']];
  $title = $field['title']; ?>

  <div class="field text">
    <label for="<?= $name ?>"><?= $title ?></label>
    <input type="text" name="<?= $name ?>" value="<?= $value ?>">
  </div>

  <?php
}