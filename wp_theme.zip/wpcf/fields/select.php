<?php

function select($meta, $meta_key, $field) {
  if (!isset($field['values'])) return;
  $name    = $meta_key . '[' . $field['name'] . ']';
  $value   = $meta[$field['name']];
  $title   = $field['title'];
  $options = $field['values']; ?>

  <div class="field select">
    <label for="<?= $name ?>"><?= $title ?></label>
    <select name="<?= $name ?>"><?php

    foreach ($options as $option_value => $option_title) { 
      $selected = ($value == $option_value) ? ' selected="selected"' : ''; ?>

      <option value="<?= $option_value ?>"<?= $selected ?>>
        <?= $option_title; ?>
      </option>

      <?php
    } ?>
    </select>
  </div>

  <?php
}