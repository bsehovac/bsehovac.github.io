<?php

function editor($meta, $meta_key, $field) {
  $name  = $meta_key . '[' . $field['name'] . ']';
  $value = $meta[$field['name']];
  $title = $field['title']; ?>

  <div class="field editor">
    <label><?= $title ?></label><?php

    wp_editor(
      htmlspecialchars_decode($value),
      $field['name'],
      $settings = array(
        'textarea_name' => $name,
        'media_buttons' => false)
      );

    ?>
  </div>

  <?php
}