<?php

function textarea($meta, $meta_key, $field) {
  $name  = $meta_key . '[' . $field['name'] . ']';
  $value = $meta[$field['name']];
  $title = $field['title']; ?>

  <div class="field textarea">
    <label for="<?= $name ?>"><?= $title ?></label>
    <textarea name="<?= $name ?>"><?= $value ?></textarea>
  </div>

  <?php
}