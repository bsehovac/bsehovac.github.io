<?php

function image($meta, $meta_key, $field) {
  $name  = $meta_key . '[' . $field['name'] . ']';
  $value = $meta[$field['name']];
  $title = $field['title'];
  $thumb = wp_get_attachment_image_src($value, 'thumbnail')[0];?>

  <div class="field image">
    <label><?=$title?></label>
    <input type="hidden" name="<?=$name?>" value="<?=$value?>">
    <div class="image-preview" image="<?=$value?>" style="background-image: url(<?=$thumb?>)">
      <i class="dashicons dashicons-plus"></i>
      <i class="dashicons dashicons-trash"></i>
    </div>
  </div>

  <?php
}