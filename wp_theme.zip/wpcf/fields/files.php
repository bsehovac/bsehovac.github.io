<?php

function file_item($name, $key = 'FILEID', $item = false, $files = false) {
  $blank = ($item) ? false : true;
  if ($blank) {
    $file  = '';
    $thumb = '';
    $input_name = 'nameplaceholder';
    $item_class = 'upload';
  } else {
    $file  = $item['file'];
    $thumb = wp_get_attachment_image_src($file, 'thumbnail')[0];
    $input_name = 'name';
    $item_class = 'item';
  } ?>

  <div class="<?=$item_class?>">
    <input type="text" placeholder="Title" class="meta title"
      <?=$input_name?>="<?=$name?>[<?=$key?>][title]" value="<?php echo $item['title']; ?>" >

    <input type="text" readonly="readonly" class="meta file"
      <?=$input_name?>="<?=$name?>[<?=$key?>][file]" value="<?php echo $item['file']; ?>" >

    <div class="icon" imgid="<?=$file?>">
      <i class="dashicons dashicons-plus"></i>
      <i class="dashicons dashicons-media-default"></i>
    </div>
  </div>

  <?php
}

function files($meta, $meta_key, $field) {
  $files   = $meta[$field['name']];
  $name    = $meta_key . '[' . $field['name'] . ']';
  $title   = $field['title']; ?>

  <div class="field files">
    <label><?=$title?></label>

    <div class="items"><?php
      if (!empty($files)) {
        foreach ($files as $key => $item) {
          file_item($name, $key, $item, $files);
        }
      }
      file_item($name);
    ?></div>

  </div>

  <?php
}