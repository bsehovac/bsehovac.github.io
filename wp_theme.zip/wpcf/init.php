<?php

/*
███████ ███████ ████████ ██    ██ ██████  
██      ██         ██    ██    ██ ██   ██ 
███████ █████      ██    ██    ██ ██████  
     ██ ██         ██    ██    ██ ██      
███████ ███████    ██     ██████  ██      
*/

$wpcf_field_types = array(
  'text',
  'textarea',
  'editor',
  'image',
  'gallery',
  'select',
  'files',
  'color',
);

foreach ($wpcf_field_types as $field) {
  include("fields/$field.php");
}

$wpcf_options = array(
  'version' => time(),
  'path'    => get_template_directory_uri() . '/wpcf/'
);

$wpcf_first = true;

if (isset($meta_boxes)) {
  add_action('load-post.php', 'wpcf_setup');
  add_action('load-post-new.php', 'wpcf_setup');
}

function wpcf_setup() {
  add_action('add_meta_boxes', 'wpcf_init');
  add_action('admin_enqueue_scripts', 'wpcf_assets');
  add_action('save_post', 'wpcf_save');
}

function wpcf_assets() {
  global $wpcf_options;

  wp_enqueue_style(
    'admin-metabox',
    $wpcf_options['path'] . 'styles.css',
    false,
    $wpcf_options['version'],
    'all'
  );

  wp_enqueue_script(
    'admin-metabox',
    $wpcf_options['path'] . 'scripts.js',
    false,
    $wpcf_options['version'],
    true
  );
}

/*
██ ███    ██ ██ ████████ 
██ ████   ██ ██    ██    
██ ██ ██  ██ ██    ██    
██ ██  ██ ██ ██    ██    
██ ██   ████ ██    ██    
*/

function wpcf_init() {
  global $post;
  global $meta_boxes;
  wp_enqueue_media();

  foreach ($meta_boxes as $meta_box) {

    $meta_box_type = $meta_box['post_type'];

    if ($meta_box_type != $post->post_type) {
      continue;
    } else if (
      $meta_box_type == 'page' &&
      get_post_meta($post->ID, '_wp_page_template', true) != $meta_box['page_tpl']
    ) {
      continue;
    }

    if (!isset($meta_box['meta_key'])) $meta_box['meta_key'] = 'wpcf';
    if (!isset($meta_box['context']))  $meta_box['context']  = 'normal';
    if (!isset($meta_box['priority'])) $meta_box['priority'] = 'default';

    $meta_box_id = 'wpcf_' . $meta_box['name'];

    add_meta_box(
      $meta_box_id,
      $meta_box['title'],
      'wpcf_render',
      $meta_box_type,
      $meta_box['context'],
      $meta_box['priority'],
      $meta_box
    );

    add_filter('postbox_classes_'. $meta_box_type .'_'. $meta_box_id, 'wpcf_class');
  }
}

function wpcf_class($classes) {
  $classes[] = 'wpcf';
  return $classes;
}

/*
██████  ███████ ███    ██ ██████  ███████ ██████  
██   ██ ██      ████   ██ ██   ██ ██      ██   ██ 
██████  █████   ██ ██  ██ ██   ██ █████   ██████  
██   ██ ██      ██  ██ ██ ██   ██ ██      ██   ██ 
██   ██ ███████ ██   ████ ██████  ███████ ██   ██ 
*/

function wpcf_render($post, $meta_box) {
  global $wpcf_first;

  $meta_box    = $meta_box['args'];
  $meta_key    = $meta_box['meta_key'];
  $meta_fields = $meta_box['fields'];
  $meta = get_post_meta($post->ID, $meta_key, true);

  if ($wpcf_first) {
    $wpcf_first = false; ?>
    <input
      type="hidden"
      name="wpcf_nonce"
      value="<?= wp_create_nonce(basename(__FILE__)) ?>">
    <?php
  } ?>

  <input
    type="hidden"
    name="wpcf_key[]"
    value="<?= $meta_key ?>">
  <input
    type="hidden"
    name="<?= $meta_key . '['. $meta_key .']' ?>"
    value="<?= $meta_key ?>">

  <?php
  wpcf_fields(
    $meta,
    $meta_key,
    $meta_fields
  );
}

/*
███████ ██ ███████ ██      ██████  ███████ 
██      ██ ██      ██      ██   ██ ██      
█████   ██ █████   ██      ██   ██ ███████ 
██      ██ ██      ██      ██   ██      ██ 
██      ██ ███████ ███████ ██████  ███████ 
*/

function wpcf_fields($meta, $meta_key, $meta_fields) {
  global $wpcf_field_types;

  foreach ($meta_fields as $field) {
    $field_type = $field['type'];
    if (!in_array($field_type, $wpcf_field_types)) continue;
    call_user_func_array($field_type, array($meta, $meta_key, $field));
  }
}

/*
███████  █████  ██    ██ ███████ 
██      ██   ██ ██    ██ ██      
███████ ███████ ██    ██ █████   
     ██ ██   ██  ██  ██  ██      
███████ ██   ██   ████   ███████ 
*/

function wpcf_save($post_id) {
  if (!wp_verify_nonce($_POST['wpcf_nonce'], basename(__FILE__))) {
    return $post_id;
  }

  if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
    return $post_id;
  }

  if ('page' === $_POST['post_type']) {
    if (!current_user_can('edit_page', $post_id)) {
      return $post_id;
    } else if (!current_user_can('edit_post', $post_id)) {
      return $post_id;
    }
  }

  if (!isset($_POST['wpcf_key'])) {
    return $post_id;
  }

  $post_meta_keys = $_POST['wpcf_key'];
  $meta_keys = array_unique($post_meta_keys);

  foreach ($meta_keys as $key => $value) {
    $meta_key = $value;

    $old = get_post_meta($post_id, $meta_key, true);
    $new = $_POST[$meta_key];
    
    if ($new && $new !== $old) {
      update_post_meta($post_id, $meta_key, $new);
    } elseif ('' === $new && $old) {
      delete_post_meta($post_id, $meta_key, $old);
    }
  }
}

/*
██   ██ ██ ██████  ███████     ███████ ██████  ██ ████████  ██████  ██████  ███████ 
██   ██ ██ ██   ██ ██          ██      ██   ██ ██    ██    ██    ██ ██   ██ ██      
███████ ██ ██   ██ █████       █████   ██   ██ ██    ██    ██    ██ ██████  ███████ 
██   ██ ██ ██   ██ ██          ██      ██   ██ ██    ██    ██    ██ ██   ██      ██ 
██   ██ ██ ██████  ███████     ███████ ██████  ██    ██     ██████  ██   ██ ███████ 
*/

if (isset($hide_editors)) {
  add_action('admin_init', 'hide_editor');
}

function hide_editor() {
  global $hide_editors;
  
  $post_id = $_GET['post'] ? $_GET['post'] : $_POST['post_ID'];

  if (!isset($post_id))
    return;

  foreach ($hide_editors as $page) {
    $template_file = get_post_meta($post_id, '_wp_page_template', true);
    if($template_file == $page){
      remove_post_type_support('page', 'editor');
    }
  }
}