<?php /* Template Name: Home Page */ get_header(); ?>

<?php $meta = get_post_meta($post->ID, 'vm_custom_fields', true); ?>

<div id="page"><div class="center">
  <h1><?php wp_title(''); ?></h1>
  <div id="slideshow" interval="<?php echo $meta['slideshow_interval']; ?>" type="<?php echo $meta['slideshow_type']; ?>">
  <?php
    $slides = $meta['slideshow'];
    foreach ($slides as $slide) {
      $image = wp_get_attachment_image_src($slide['img'], 'full');
      ?>
      <div class="slide">
        <img src="<?php echo $image[0]; ?>" />
        <p><?php echo $slide['title']; ?></p>
        <p><?php echo $slide['description']; ?></p>
        <p><?php echo $slide['url']; ?></p>
      </div>
      <?php
    }
  ?>
  </div>
</div></div>

<?php modal_window('Modal Title', 'Lorem ipsum dolor sit amet'); ?>

<?php get_footer(); ?>
