  <div id="footer">
    <div class="center">
      <a href="<?php echo home_url(); ?>" id="footer-logo" class="logo"><span><?php echo get_bloginfo('name'); ?></span></a>
    </div>
  </div>
  <?php wp_footer(); ?>
</body>
</html>
