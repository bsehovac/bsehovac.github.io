<?php function modal_window($title, $text) { ?>

  <div id="modal" style="display: none;">
    <div id="modal-overlay"></div>
    <div id="modal-fixer"></div>
    <div id="modal-window">
      <div id="modal-content">
        <h1><?php echo $title; ?></h1>
        <p><?php echo $text; ?></p>
      </div>
      <div id="modal-buttons">
        <button id="modal-ok" class="button">U redu</button>
      </div>
    </div>
  </div>

<?php } ?>
